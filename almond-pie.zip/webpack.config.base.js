var port = 80,
    localIp = 'dev.zhongan.com',
    // "192.168.200.187",
    HtmlWebpackPlugin = require("html-webpack-plugin"),
    webpack = require("webpack"),
    OpenBrowserWebpackPlugin = require("open-browser-webpack-plugin"),
    path = require("path");

module.exports = {
    // devtool: 'source-map',
    entry: {
        app: [ 'react-hot-loader/patch', 
        'webpack-dev-server/client?http://dev.zhongan.com',
            'webpack/hot/only-dev-server',
            './src/app.js'
        ]
    },
    output: {
        filename: "[name].js",
        publicPath: '/',
        path: path.resolve(__dirname, "dist")
    },
    resolve: {
        extensions: [
            '.js', '.jsx', '.scss'
        ],
        alias: {
            zarm: __dirname + '/node_modules/zarm',
            src: __dirname + '/src',
            actions: __dirname + '/src/actions',
            style: __dirname + '/src/style',
            constants: __dirname + '/src/constants',
            containers: __dirname + '/src/containers',
            components: __dirname + '/src/components',
            reducers: __dirname + 'reducers',
            utils: __dirname + '/src/utils'
        }
    },
    module: {
        rules: [ {
                test: /\.js$/,
                use: [
                    'babel-loader', 'react-hot-loader/webpack'
                ],
                exclude: [/(node_modules)/]
            }, {
                test: /\.(jpg|jpeg|gif|png)$/,
                use: [
                    {
                        loader: 'url-loader',
                        options: {
                            limit: 10000
                        }
                    }
                ]
            }, {
                test: /\.(eot|ttf|woff|woff2|svg)$/,
                use: 'file-loader?publicPath=../../&name=static/css/[hash].[ext]'
            }
        ]
    },
    plugins: [new HtmlWebpackPlugin({template: "./src/index.html"})]
};