
import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';
import { Mask, Icon, Toast } from 'zarm';
import './index.scss';



let StaticToast = {
  default: (message, callback, duration, theme) => {
    let div = document.createElement('div');
    document.body.appendChild(div);
    ReactDOM.render((
        <Toast
          duration={ duration || 3000 }
          visible={ true }
          onMaskClick={ () => {
            ReactDOM.unmountComponentAtNode(div);
            document.body.removeChild(div);
            callback && callback();
          }}>
           <Icon type={ theme || "wrong-round" } style={{ fontSize: '3rem' }} /> 
          <p className="content">{ message }</p>
        </Toast>), div);
  },
  info: (message, callback, duration) => {
    StaticToast.default(message, callback, duration);
  },

  success: (message, callback, duration) => {
    StaticToast.default(message, callback, duration, "right-round-fill");
  },

  warning: (message, callback, duration) => {
    StaticToast.default(message, callback, duration);
  },

  error: (message, callback, duration) => {
    StaticToast.default(message, callback, duration, "info-round");
  }
}

export default StaticToast; 