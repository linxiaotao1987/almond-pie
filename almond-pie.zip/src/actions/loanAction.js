// export default {
  
//       /**
//        * 
//        */
//       // updLoanList(list){
//         return (dispatch,getState)=>{
  
//           dispatch({
//             type: 'UPDATE_CARD_ADMIN_STATE_LOAN_LIST',
//             data: {
//               list 
//             }
//           })
          
//         };
//       }
//   };
  