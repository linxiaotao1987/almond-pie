export default {

    updCardAdminState(attr,value){
      return (dispatch,getState)=>{
        setTimeout(()=> {
          dispatch({
            type: 'UPDATE_CARD_ADMIN_STATE',
            data: {
              [attr] : value
            }
          })
        },3000)
        
        
      };
    }
};
