import {combineReducers} from "redux";
import cardAdmin from './cardAdmin';

export default combineReducers({
    cardAdmin
});
  