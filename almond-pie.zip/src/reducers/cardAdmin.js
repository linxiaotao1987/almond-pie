let initState = {
    name : "自助卡1管理后台1222",
    loanList : [{},{},{},{},{}]
};

function cardAmind(state = initState, action) {
    switch (action.type) {
        case "UPDATE_CARD_ADMIN_STATE":
            var newState = Object.assign({}, state, action.data);
            return newState;
        default:
            return state;
    };
};

export default cardAmind; 