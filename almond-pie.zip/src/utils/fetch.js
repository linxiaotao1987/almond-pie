import promise from 'es6-promise'
import fetch from 'isomorphic-fetch';
import StaticToast from 'components/common/toast'
import {DebugLogs, ErrorLogs} from 'src/utils/logs';
import Crypto from 'utils/crypto';
promise.polyfill();

/**
 *
 * @param {*} app_id 腾讯服务分配的 app_id
 * @param {*} secret 腾讯服务 app_id的密钥
 */
async function getAccessToken(app_id, secret) {
  var version = "1.0.0";
  //
  // fetch(`https://idasc.webank.com/api/oauth2/access_token?app_id=${app_id}&secr
  // e t=${secret}&grant_type=client_credential&version=${version}`) return false;
  // return fetch('') .then((res) => res.json()); return
  fetch(`http://matrix-test.zhongan.com/trans`,
  {   method:'post',   
  mode: 'no-cors',
    headers : {
      Accept : 'applicatiopn/json',     
      'Content-Type' :'application/json', 
  },   
  body : JSON.stringify(Crypto.encrypt()) }) .then((res)=>res.text()).then(()=>{
    debugger;
  })


  // fetch(`https://idasc.webank.com/api/oauth2/access_token?app_id=${app_id}&secret=${secret}&grant_type=client_credential&version=${version}`, {
  //   mode: 'no-cors',
  //   headers: {
  //     'Accept': 'application/json',
  //     'Content-Type': 'application/json'
  //   }
  // }).then((res)=>res.json()).then(()=>{debugger;})

  return false;
  var res = await fetch(`https://idasc.webank.com/api/oauth2/access_token?app_id=${app_id}&secret=${secret}&grant_type=client_credential&version=${version}`, {
    mode: 'no-cors',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    }
  })
  var result = await res.text();
  debugger;
  return result;
  // debugger; .then((res)=> res.json()) ) debugger; .then( (res)=> await
  // res.json())
}

/**
 * 腾讯云服务 获取nonceTicket
 * @param {*} app_id 腾讯服务分配的 app_id
 * @param {*} access_token
 * @param {*} openId 用户的唯一ID
 */
function getNonceTicket(app_id, access_token, openId) {
  var type = "NONCE";
  var version = "1.0.0";
  fetchJson({
    url: `https://idasc.webank.com/api/oauth2/api_ticket?app_id=${app_id}&access_token=${access_token}&type=${type}&version=${version}&userId=${openId}`,
    success: function (res = {
      "code": "0",
      "msg": "请求成功",
      "transactionTime": "20151022044027",
      "tickets": [
        {
          "value": "ticket_string",
          "expire_in": "120",
          "expire_time": "20151022044027"
        }
      ]
    }) {}
  })
}

/**
 * SHA1 加密
 * @param {*} data
 */
function sha1(data) {
  var i,
    j,
    t;
  var l = ((data.length + 8) >>> 6 << 4) + 16,
    s = new Uint8Array(l << 2);
  s.set(new Uint8Array(data.buffer)),
  s = new Uint32Array(s.buffer);
  for (t = new DataView(s.buffer), i = 0; i < l; i++) 
    s[i] = t.getUint32(i << 2);
  s[data.length >> 2] |= 0x80 << (24 - (data.length & 3) * 8);
  s[l - 1] = data.length << 3;
  var w = [],
    f = [
      function () {
        return m[1] & m[2] |~ m[1] & m[3];
      },
      function () {
        return m[1] ^ m[2] ^ m[3];
      },
      function () {
        return m[1] & m[2] | m[1] & m[3] | m[2] & m[3];
      },
      function () {
        return m[1] ^ m[2] ^ m[3];
      }
    ],
    rol = function (n, c) {
      return n << c | n >>> (32 - c);
    },
    k = [
      1518500249, 1859775393, -1894007588, -899497514
    ],
    m = [1732584193, -271733879, null, null, -1009589776];
  m[2] =~ m[0],
  m[3] =~ m[1];
  for (i = 0; i < s.length; i += 16) {
    var o = m.slice(0);
    for (j = 0; j < 80; j++) 
      w[j] = j < 16
        ? s[i + j]
        : rol(w[j - 3] ^ w[j - 8] ^ w[j - 14] ^ w[j - 16], 1),
      t = rol(m[0], 5) + f[j / 20 | 0]() + m[4] + w[j] + k[j / 20 | 0] | 0,
      m[1] = rol(m[1], 30),
      m.pop(),
      m.unshift(t);
    for (j = 0; j < 5; j++) 
      m[j] = m[j] + o[j] | 0;
    };
  t = new DataView(new Uint32Array(m).buffer);
  for (var i = 0; i < 5; i++) 
    m[i] = t.getUint32(i << 2);
  return new Uint8Array(new Uint32Array(m).buffer);
};

/**
 * 生成SHA1签名 长度40
 * @param {*} version
 * @param {*} orderNo
 * @param {*} webankAppId
 * @param {*} nonce
 * @param {*} userId
 * @param {*} ticket
 */
function sign(version = '1.0.0', orderNo = "aabc1457895464", webankAppId = 'appId001', nonce = "kHoSxvLZGxSoFsjxlbzEoUzh5PAnTU7T", userId = 'userID19959248596551', ticket = "zxc9Qfxlti9iTVgHAjwvJdAZKN3nMuUhrsPdPlPVKlcyS50N6tlLnfuFBPIucaMS") {
  var str = arguments.join('');
  return sha1(str);
}

/**
 * 启动活体校验
 * @param {*} webankAppId
 * @param {*} version
 * @param {*} nonce
 * @param {*} orderNo
 * @param {*} url
 * @param {*} userId
 * @param {*} sign
 * AKIDlPvIUU99ufJmDYEmkbGweFhxiNrAnOIC
 * pRyJSaVEk9PTM3sALQLArSt9HHG7av69
 */
export async function aliveCheck(webankAppId = 'TIDAQrq2', sercretId = 'KuFk8OeJtmhJGGzGnCbXWwDeE0iAWzvS7EEcNrL7RmePKmIfg76D2a0xOH9KdkuE', version, nonce, orderNo, url, userId, sign) {
  //获取 ACCESS_TOKEN
  try {
    var res = await getAccessToken(webankAppId, sercretId);
    // var result = await res.json();
    // debugger;
    // p.then((res)=> console.log(res))
    // console.log("<><><><>", result)
  } catch (e) {
    console.log("<><><><>", e)
    // debugger;
  }

  // https://ida.webank.com/api/wx/livelogin window.location.href =
  // `https://ida.webank.com/api/wx/livelogin?webankAppId=${webankAppId}&version=$
  // {
  // version}&nonce=${nonce}&orderNo=${orderNo}&url=${url}&userId=${url}&sign=${ur
  // l }`
}

/**
 * 发起json形式的fetch请求
 * @param {Object} options
 */
export const fetchJson = (options) => {
  options.url = /^https:\/\//.test(options.url) || /^\/\//.test(options.url)
    ? options.url
    : DEPLOY_ENV + options.url;
  let {
    url,
    type,
    data,
    headers,
    noCredentials,
    credentials,
    ...others
  } = options;
  Loading(true);
  let opts = {
    ...others,
    method: type || 'get',
    _url: url,
    credentials: 'include',
    headers: headers
      ? headers
      : {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
  }
  if (noCredentials) {
    delete opts.credentials;
  }

  if (['POST', 'PUT'].indexOf(opts.method.toUpperCase()) >= 0) {
    opts.body = JSON.stringify(data);
  };

  fetch(url, opts).then(resData => {
    return toJson(resData, opts)
  })
    .then(resData => resHandler(resData, opts))
    .catch(error => errorHandler(error, opts))
}

function toJson(resp, options) {
  if (resp.status >= 400) {
    return errorHandler(null, options, resp.status)
  }
  return resp.json()
}

// 请求成功处理
function resHandler(resData, options) {
  Loading(false);
  if (resData.status && resData.status != 200) {
    return errorHandler(resData.error, options, resData.status);
  }
  if (!resData || resData.code > 20000) {
    options.error && options.error(resData);
    StaticToast.error(resData.message);
  } else {
    options.success && options.success(resData);
  };
  if (resData.code != 0) { //code！=0 的异常上报
    DebugLogs(options._url, resData);
  };
}

// 异常处理
function errorHandler(error, options, status) {
  options.error && options.error(error);
  StaticToast.error(`网络异常，请稍后重试(${status})`);
  Loading(false);
  ErrorLogs(options._url, {status, error});
}

export function Loading(IsShow) {
  var loading = document.querySelector('#loadTips');
  if (!loading && !IsShow) {
    return;
  };
  if (loading) {
    loading.className = !IsShow
      ? "wb-fix hide"
      : "wb-fix";
  } else {
    var str = '<div class="ui-loading ui-loading-open" ><div class="ui-loading-container"><div ' +
        'class="ui-loading-items" ><div class="ui-loading-item" ></div><div class="ui-loa' +
        'ding-item" ></div><div class="ui-loading-item" ></div><div class="ui-loading-ite' +
        'm" ></div><div class="ui-loading-item" ></div><div class="ui-loading-item" ></di' +
        'v><div class="ui-loading-item" ></div><div class="ui-loading-item" ></div><div c' +
        'lass="ui-loading-item" ></div><div class="ui-loading-item" ></div><div class="ui' +
        '-loading-item"></div><div class="ui-loading-item"></div></div></div><div class="' +
        'ui-mask transparent"></div></div>';
    var CreateLoad = document.createElement("div");
    CreateLoad.id = "loadTips";
    CreateLoad.className = !IsShow
      ? "wb-fix hide"
      : "wb-fix";
    CreateLoad.innerHTML = (str);
    document
      .body
      .appendChild(CreateLoad);
  };
};