var AES = require("crypto-js/aes");
// var RSA = require("crypto-js/rsa");
var UTF8 = require("crypto-js/enc-utf8")
var BASE64 = require("crypto-js/enc-base64")
var PKCS7 = require("crypto-js/pad-pkcs7")
var ECB = require("crypto-js/mode-ecb");
// var JSEncrypt = require("jsencrypt");


import {JSEncrypt} from 'jsencrypt';

/**
*   随机生成对应长度的字符串
 * @param {Number} length 生产的字符串长度
 * @returns {String} str
 */
function genRandomString(length = 16) {
  var str = [];
  var strs = "0123456789abcdefghijklnmopqrstuvwxyz";
  for(var i = 0;i<length;i++){
    var index = Math.floor(Math.random()*strs.length);
    str.push(strs[index]);
  }
  return str.join('');

}

/**
 * 请求参数加密
 * @param {String |Object } reqContent 请求参数
 */
// 
// 

//6、放入key 7、请求matrix
// 8、获取返回报文后，用RSA_PU_KEY对sign验签，签名内容为原AES_KEY。

function encrypt(
  reqContent=JSON.stringify({name : "Focus",sex:1,age:18,children:[{name : "Shadow"}]}),
  RSA_PU_KEY="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCF+e7AqfviPHYseitSRq53JDgm0q2cGQHFiiD0eVGNk8zMmoOYebGAcPtsiy8g5JmZwTP7ij17A2/ai5NOnWawm5JmF9Xc84a1RGHIgnjQjifJS3i+ck5kkx6sbZkcc8qdn0zo2VcUeQ9HhZn8/0XKN8WvPvBWAPU+Hw4x/yaKnwIDAQAB"){
  // 1、前端随机生成16个字符，作为AES_KEY 
  const AES_KEY = genRandomString();
  // 2、将AES_KEY、reqContent转为UTF-8编码字节数组
  const AES_KEY_UTF8 = UTF8.parse(AES_KEY);
  var reqContent_UTF8 = UTF8.parse(reqContent);
  // 3、使用 AES_KEY字节数组对reqContent  AES/ECB/PKCS5Padding 方式加密
  var ciphertext = AES.encrypt(reqContent_UTF8, AES_KEY_UTF8, {
    mode: ECB,
    padding: PKCS7
  }).ciphertext;
  // 4、获得加密后字节数组进行Base64编码，然后转化成字符串 
  var cipherContent = BASE64.stringify(ciphertext);
  //  方式 对key进行加密，经过base64编码获得密文
  // 5、用RSA_PU_KEY  RSA/ECB/PKCS5Padding
  var cipherKey = encryptKey(AES_KEY,RSA_PU_KEY);
  return {
    apiVersion : '1.0.0',
    thirdUserNo :'uuid123456789',
    productCode : 'XR',
    client:'WX',
    key : cipherKey,
    reqContent : cipherContent
  }
}


/**
 * 通过RSA形式加密随机生成的key 公钥是RSA_PU_KEY
 * @param {*} key 
 * @param {*} RSA_PU_KEY 
 */
function encryptKey(key,RSA_PU_KEY){
  var encrypt = new JSEncrypt();
  encrypt.setPublicKey(RSA_PU_KEY);

  var cipherKey = encrypt.encrypt(key);
  BASE64.parse(cipherKey);
  return  cipherKey;
}

/**
 * 通过私钥解密key ，仅测试用，私钥在金融服务端
 * @param {*} cipherKey 
 */
// function decryptKey(cipherKey){
//   var encrypt = new JSEncrypt();
//   encrypt.setPrivateKey(
//     `MIICXQIBAAKBgQDlOJu6TyygqxfWT7eLtGDwajtNFOb9I5XRb6khyfD1Yt3YiCgQ
//   WMNW649887VGJiGr/L5i2osbl8C9+WJTeucF+S76xFxdU6jE0NQ+Z+zEdhUTooNR
//   aY5nZiu5PgDB0ED/ZKBUSLKL7eibMxZtMlUDHjm4gwQco1KRMDSmXSMkDwIDAQAB
//   AoGAfY9LpnuWK5Bs50UVep5c93SJdUi82u7yMx4iHFMc/Z2hfenfYEzu+57fI4fv
//   xTQ//5DbzRR/XKb8ulNv6+CHyPF31xk7YOBfkGI8qjLoq06V+FyBfDSwL8KbLyeH
//   m7KUZnLNQbk8yGLzB3iYKkRHlmUanQGaNMIJziWOkN+N9dECQQD0ONYRNZeuM8zd
//   8XJTSdcIX4a3gy3GGCJxOzv16XHxD03GW6UNLmfPwenKu+cdrQeaqEixrCejXdAF
//   z/7+BSMpAkEA8EaSOeP5Xr3ZrbiKzi6TGMwHMvC7HdJxaBJbVRfApFrE0/mPwmP5
//   rN7QwjrMY+0+AbXcm8mRQyQ1+IGEembsdwJBAN6az8Rv7QnD/YBvi52POIlRSSIM
//   V7SwWvSK4WSMnGb1ZBbhgdg57DXaspcwHsFV7hByQ5BvMtIduHcT14ECfcECQATe
//   aTgjFnqE/lQ22Rk0eGaYO80cc643BXVGafNfd9fcvwBMnk0iGX0XRsOozVt5Azil
//   psLBYuApa66NcVHJpCECQQDTjI2AQhFc1yRnCU/YgDnSpJVm1nASoRUnU8Jfm3Oz
//   uku7JUXcVpt08DFSceCEX9unCuMcT72rAQlLpdZir876`);
//   var key = encrypt.decrypt(cipherKey);
//   alert(key);
//   return  key;
// }

export default {
  encrypt,
  decrypt: function () {}
}

// obj.encode();