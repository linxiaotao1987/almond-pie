/**
 *  自助卡配置后台首页
 * @author Focus Wong
 */

import React from 'react';
import {Route, Link, withRouter} from "react-router-dom";
import LazyRoute from "lazy-route";

import "zarm/styles/index.scss"; 

export default class Home extends React.Component {
  render() {
       return <div>
          <Route exact path='/' render={props => (<LazyRoute {...props} component={import ('../almond/home')}/>)}/>
          <Route path='/apply' render={props => (<LazyRoute {...props} component={import ('../almond/apply')}/>)}/>
          <Route path='/repayment' render={props => (<LazyRoute {...props} component={import ('../almond/repayment')}/>)}/>
          {/* <Route path='/pwd' render={props => (<LazyRoute {...props} component={import ('../almond/pwd')}/>)}/> */}
          <Route path='/loan' render={props => (<LazyRoute {...props} component={import ('../almond/loan')}/>)}/>
          <Route path='/personal' render={props => (<LazyRoute {...props} component={import ('../almond/personal')}/>)}/>
        </div>
  }
}