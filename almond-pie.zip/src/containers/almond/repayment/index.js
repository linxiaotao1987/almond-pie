import React from 'react';
import {Route, Switch,Link, withRouter} from "react-router-dom";
import LazyRoute from "lazy-route";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import './index.scss'
import Actions from 'actions';
import Loadable from 'react-loadable';
import Loading from 'components/loading'
// import IdCard from ''

// import {Cell} from 'zarm';


const Ant = Loadable.Map({
  loader:{
    Cell :() => import('zarm/lib/Cell'),
    Button :() => import('zarm/lib/Button'),
  },
  loading : Loading,
  render(loaded, props){
    let {Cell,Button} = loaded;
    Cell = Cell.default;
    Button = Button.default;
    let {name} = props.cardAdmin
    let {updCardAdminState} = props.actions;
    return <div>
            {/* 本期应还 */}
            <Route exact path={`${props.match.url}`} render={props => (<LazyRoute {...props} component={import ('./current')}/>)}/>
            <Route exact path={`${props.match.url}/list`} render={props => (<LazyRoute {...props} component={import ('./list')}/>)}/>
          </div>
  }
});


/**
 * 自助卡配置器后台首页
 */
class Comp extends React.Component {
  constructor() {
    super();
  }
  render() { 
    return <Ant {...this.props}/>
  }
}

let mapStateToProps = (state) => {
  const {cardAdmin} = state;
  return {cardAdmin};
};

let mapDispatchToProps = (dispatch) => {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Comp);