import React from 'react';
import {Route, Link, withRouter} from "react-router-dom";
import LazyRoute from "lazy-route";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import './index.scss'
import Actions from 'actions';
import Loadable from 'react-loadable';
import Loading from 'components/loading'

// import {Cell} from 'zarm';


const Ant = Loadable.Map({
  loader:{
    Cell :() => import('zarm/lib/Cell'),
    Button :() => import('zarm/lib/Button'),
  },
  loading : Loading,
  render(loaded, props){
    let {Cell,Button} = loaded;
    Cell = Cell.default;
    Button = Button.default;
    let {name} = props.cardAdmin
    let {updCardAdminState} = props.actions;
    return <div>
        <Cell>还款记录</Cell>
        <Link to="/loan/detail">借款详情</Link>
        <Link to="/loan/more">更多详情详情</Link>
    </div>
  }
});


/**
 * 自助卡配置器后台首页
 */
class Comp extends React.Component {
  constructor() {
    super();
  }
  render() { 
    return <Ant {...this.props}/>
  }
}

let mapStateToProps = (state) => {
  const {cardAdmin} = state;
  return {cardAdmin};
};

let mapDispatchToProps = (dispatch) => {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Comp);