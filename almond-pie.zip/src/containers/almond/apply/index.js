import React from 'react';
import {Route, Switch,Link, withRouter} from "react-router-dom";
import LazyRoute from "lazy-route";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import './index.scss'
import Actions from 'actions';
import Loadable from 'react-loadable';
import Loading from 'components/loading'
// import IdCard from ''

// import {Cell} from 'zarm';


const Ant = Loadable.Map({
  loader:{
    Cell :() => import('zarm/lib/Cell'),
    Button :() => import('zarm/lib/Button'),
  },
  loading : Loading,
  render(loaded, props){
    let {Cell,Button} = loaded;
    Cell = Cell.default;
    Button = Button.default;
    let {name} = props.cardAdmin
    let {updCardAdminState} = props.actions;
    return <div>
        <Cell>授信申请</Cell>
        <div>1-2-3-4</div>
        <div>
              <Route exact path={`${props.match.url}/idCard`} render={props => (<LazyRoute {...props} component={import ('./idCard')}/>)}/>
              <Route exact path={`${props.match.url}/imformation`} render={props => (<LazyRoute {...props} component={import ('./imformation')}/>)}/>
              <Route exact path={`${props.match.url}/bankCard`} render={props => (<LazyRoute {...props} component={import ('./bankCard')}/>)}/>
              <Route exact path={`${props.match.url}/result`} render={props => (<LazyRoute {...props} component={import ('./result')}/>)}/>
        </div>
    </div>
  }
});


/**
 * 自助卡配置器后台首页
 */
class Comp extends React.Component {
  constructor() {
    super();
  }
  render() { 
    return <Ant {...this.props}/>
  }
}

let mapStateToProps = (state) => {
  const {cardAdmin} = state;
  return {cardAdmin};
};

let mapDispatchToProps = (dispatch) => {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Comp);