import React from 'react';
import {Route, Link, withRouter} from "react-router-dom";
import LazyRoute from "lazy-route";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import './index.scss'
import Actions from 'actions';
import Loadable from 'react-loadable';
import Loading from 'components/loading'

// import {Cell} from 'zarm';


const Ant = Loadable.Map({
  loader:{
    Cell :() => import('zarm/lib/Cell'),
    Button :() => import('zarm/lib/Button'),
  },
  loading : Loading,
  goToResult: (props)=>{
    props.history.push('/apply/result')
  },
  render(loaded, props){
    let {Cell,Button} = loaded;
    Cell = Cell.default;
    Button = Button.default;
    let {name} = props.cardAdmin
    let {updCardAdminState} = props.actions;
    return <div>
        <Cell>绑定银行卡</Cell>
        <a onClick={this.goToResult.bind(this,props)}>下一步</a>
    </div>
  }
});


/**
 * 自助卡配置器后台首页
 */
@withRouter
class Comp extends React.Component {
  constructor() {
    super();
  }
  render() { 
    return <Ant {...this.props}/>
  }
}

let mapStateToProps = (state) => {
  const {cardAdmin} = state;
  return {cardAdmin};
};

let mapDispatchToProps = (dispatch) => {
  return {
    actions: bindActionCreators(Actions, dispatch)
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Comp);